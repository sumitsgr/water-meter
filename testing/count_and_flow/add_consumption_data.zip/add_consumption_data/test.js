// const cron = require("node-cron");

// // cron.schedule("* */5 * * * *", async () => {
// // 	// Running at every 5th minute
// // 	console.log("* */5 * * * *", "at every 5th minute");
// // });

// cron.schedule("*/5 * * * *", async () => {
// 	// Running at every 5th minute
// 	console.log("*/5 * * * *", "at every 5th minute");
// });

// console.log("test running!");

// test mysql
const mysql = require("mysql");
let connection = mysql.createPool({
	host: "127.0.0.1",
	port: 3306,
	user: "admin",
	password: "password",
	database: "agra_db",
	connectionLimit: 50,
	dateStrings: ["DATE", "DATETIME"],
	supportBigNumbers: true,
	bigNumberStrings: true,
});

function doQuery(query, user_data_arr = []) {
	return new Promise((resolve, reject) => {
		connection.query(query, user_data_arr, function selectCb(err, results) {
			if (err) {
				console.log(err);
				return reject(err);
			} else {
				return resolve(results);
			}
		});
	});
}

(async () => {
	// let update_query = await doQuery(`UPDATE master_device SET ipaddress = "127.0.0.1" WHERE id = 1;`);
	// console.log("update_query result: ", update_query);
	// console.log("changedRows: ", update_query.changedRows);

	let zone_id,
		tuple_exists,
		ward_id = 39;
	await Promise.all([
		doQuery(`SELECT zone_id FROM wards WHERE id = ${ward_id};`),
		doQuery(`SELECT id FROM alarm_master WHERE ward_id = ${ward_id};`),
	]).then((values) => {
		console.log("values are: ", values);
		zone_id = values[0][0].zone_id;
		if (values[1].length > 0) tuple_exists = values[1][0].id;
	});

	console.log("zone_id: ", zone_id, "tuple_exists: ", tuple_exists);

	if (tuple_exists) {
		console.log("Do something when tuple exists");
	}

	// let zone_id = 2,
	// 	ward_id = 39;

	// let alarm_obj = {
	// 	meter_cover_opened: 0,
	// 	fitting_removed: 0,
	// 	magnetic_affected: 0,
	// 	battery_cover_opened: 0,
	// 	leakage_penalty: 0,
	// 	meter_disabled: 0,
	// 	reverse_flow: 0,
	// 	battery_dead: 0,
	// 	first_boot: 0,
	// 	periodic: 0,
	// 	reconnection: 0,
	// 	manual_connection: 0,
	// 	downlink_issue: 0,
	// };

	// let insert_alarm = await doQuery(
	// 	`INSERT INTO alarm_master SET zone_id = ${zone_id}, ward_id = ${ward_id}, ?, update_time = NOW();`,
	// 	[alarm_obj]
	// );

	// console.log("insert_alarm: ", insert_alarm);
})();
